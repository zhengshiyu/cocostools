﻿using System;
using LuaInterface;

public static class TestProtol
{
    public static LuaByteBuffer data; 
}
